Projeto JSF utilizando:
- Lombok: para gerar os getters e setters dos modelos
- BootsFaces: bootstrap para trabalhar com JSF
- SQLite: banco de dados